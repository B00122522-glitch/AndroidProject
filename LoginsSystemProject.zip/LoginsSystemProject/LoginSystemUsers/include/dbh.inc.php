<?php

$servername = "localhost";
$DbUserName = "root";
$DbPassword = "";
$DbName = "loginsystem";

$conn = mysqli_connect($servername, $DbUserName, $DbPassword, $DbName);

if(!$conn) {
     die("Connection failed: ".mysqli_connect_error());
}